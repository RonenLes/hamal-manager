"""
missions_DB_module.py — Core Data Layer for Hamilog
=====================================================

This module defines every Pydantic model used by the application, provides an
in-memory database fallback (so the app runs without MongoDB), and implements
the **constraint engine** that matches drivers to missions based on vehicle
capacity, cooling requirements, and priority scoring.

Key components:
    - Enums: MissionStatus, Priority, CarType, DriverStatus
    - Pydantic models: CargoSpecifications, Location, Mission, Driver
    - InMemoryDB: dict-backed store pre-seeded with sample data
    - Constraint engine helpers: check_driver_mission_compatibility,
      get_compatible_missions, calculate_match_score
"""

from __future__ import annotations

import re
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, List, Optional, Tuple

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class MissionStatus(str, Enum):
    """Lifecycle states a mission can be in."""
    available = "available"
    assigned = "assigned"
    in_transit = "in_transit"
    delivered = "delivered"
    cancelled = "cancelled"


class Priority(str, Enum):
    """Mission urgency levels — also used for scoring."""
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"


class DriverStatus(str, Enum):
    """Driver availability states."""
    available = "available"
    on_mission = "on_mission"
    offline = "offline"
    blacklisted = "blacklisted"


class CarType(str, Enum):
    """
    Vehicle classifications.  Each type has hard limits on weight, volume,
    and whether it supports cooling.  See ``CAR_SPECS`` for the mapping.
    """
    sedan = "sedan"
    suv = "suv"
    van = "van"
    refrigerated_van = "refrigerated_van"


# ---------------------------------------------------------------------------
# Car capacity look-up table
# ---------------------------------------------------------------------------

CAR_SPECS: Dict[CarType, Dict] = {
    CarType.sedan: {
        "max_weight": 50.0,    # kg
        "max_volume": 200.0,   # liters
        "cooling": False,
    },
    CarType.suv: {
        "max_weight": 150.0,
        "max_volume": 600.0,
        "cooling": False,
    },
    CarType.van: {
        "max_weight": 500.0,
        "max_volume": 2000.0,
        "cooling": False,
    },
    CarType.refrigerated_van: {
        "max_weight": 400.0,
        "max_volume": 1500.0,
        "cooling": True,
    },
}


# ---------------------------------------------------------------------------
# Pydantic Models
# ---------------------------------------------------------------------------

class CargoSpecifications(BaseModel):
    """Physical properties of the cargo to be transported."""
    volume_liters: float = Field(..., ge=0, description="Cargo volume in liters")
    weight_kg: float = Field(..., ge=0, description="Cargo weight in kilograms")
    requires_cooling: bool = Field(default=False, description="Whether the cargo needs refrigeration")


class Location(BaseModel):
    """A GPS coordinate with a human-readable address."""
    lat: float = Field(..., ge=-90, le=90)
    lng: float = Field(..., ge=-180, le=180)
    address: str = Field(..., min_length=1)


class Mission(BaseModel):
    """
    A delivery mission from pickup to dropoff.

    The ``id`` is auto-generated when the model is instantiated (unless
    explicitly provided, e.g. when loading from a database).
    """
    id: str = Field(default_factory=lambda: f"msn_{uuid.uuid4().hex[:8]}")
    title: str
    description: str
    status: MissionStatus = MissionStatus.available
    cargo: CargoSpecifications
    pickup: Location
    dropoff: Location
    assigned_driver_id: Optional[str] = None
    priority: Priority = Priority.medium
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Driver(BaseModel):
    """
    A volunteer driver with a specific vehicle type.

    ``current_location`` is updated in real-time via the GPS WebSocket.
    """
    id: str
    name: str
    email: str
    phone: str
    car_type: CarType
    status: DriverStatus = DriverStatus.available
    current_location: Optional[Location] = None
    current_mission_id: Optional[str] = None


# ---------------------------------------------------------------------------
# In-Memory Database
# ---------------------------------------------------------------------------

class InMemoryDB:
    """
    A lightweight, dict-backed store that mirrors the interface we would
    expose through Motor/MongoDB.  Pre-seeded with sample data so the app
    is immediately functional without any external database.
    """

    def __init__(self) -> None:
        self.missions: Dict[str, dict] = {}
        self.drivers: Dict[str, dict] = {}
        self._seed()

    # ----- seeding ----------------------------------------------------------

    def _seed(self) -> None:
        """Populate the store with realistic sample missions and drivers."""
        now = datetime.now(timezone.utc)

        sample_missions: List[Mission] = [
            Mission(
                id="msn_001",
                title="Medical Supplies to Shelter A",
                description="Urgent delivery of first-aid kits and medications to the northern shelter.",
                status=MissionStatus.available,
                cargo=CargoSpecifications(volume_liters=45.0, weight_kg=30.0, requires_cooling=True),
                pickup=Location(lat=32.0853, lng=34.7818, address="Tel Aviv Medical Center"),
                dropoff=Location(lat=32.1093, lng=34.8553, address="Shelter A, Ramat Gan"),
                priority=Priority.critical,
                created_at=now,
                updated_at=now,
            ),
            Mission(
                id="msn_002",
                title="Food Packages — Downtown Distribution",
                description="120 family food packages for downtown distribution point.",
                status=MissionStatus.available,
                cargo=CargoSpecifications(volume_liters=1800.0, weight_kg=450.0, requires_cooling=False),
                pickup=Location(lat=32.0667, lng=34.7667, address="Central Warehouse, Tel Aviv"),
                dropoff=Location(lat=32.0700, lng=34.7700, address="Downtown Distribution Center"),
                priority=Priority.high,
                created_at=now,
                updated_at=now,
            ),
            Mission(
                id="msn_003",
                title="Blankets to Community Center",
                description="50 thermal blankets for overnight volunteers.",
                status=MissionStatus.available,
                cargo=CargoSpecifications(volume_liters=500.0, weight_kg=80.0, requires_cooling=False),
                pickup=Location(lat=31.7683, lng=35.2137, address="Jerusalem Logistics Hub"),
                dropoff=Location(lat=31.7750, lng=35.2200, address="Community Center, Jerusalem"),
                priority=Priority.medium,
                created_at=now,
                updated_at=now,
            ),
            Mission(
                id="msn_004",
                title="Frozen Vaccines — Clinic B",
                description="Temperature-sensitive vaccines requiring cold-chain transport.",
                status=MissionStatus.available,
                cargo=CargoSpecifications(volume_liters=30.0, weight_kg=15.0, requires_cooling=True),
                pickup=Location(lat=32.7940, lng=34.9896, address="Haifa Pharma Depot"),
                dropoff=Location(lat=32.8000, lng=35.0000, address="Clinic B, Haifa"),
                priority=Priority.critical,
                created_at=now,
                updated_at=now,
            ),
            Mission(
                id="msn_005",
                title="Office Supplies — HQ Restock",
                description="Paper, pens, and printer cartridges for the operations HQ.",
                status=MissionStatus.available,
                cargo=CargoSpecifications(volume_liters=120.0, weight_kg=40.0, requires_cooling=False),
                pickup=Location(lat=32.0853, lng=34.7818, address="Office Depot, Tel Aviv"),
                dropoff=Location(lat=32.0900, lng=34.7900, address="Hamilog HQ"),
                priority=Priority.low,
                created_at=now,
                updated_at=now,
            ),
            Mission(
                id="msn_006",
                title="Water Pallets — Southern Outpost",
                description="Heavy pallet of bottled water for southern volunteer outpost.",
                status=MissionStatus.available,
                cargo=CargoSpecifications(volume_liters=1500.0, weight_kg=480.0, requires_cooling=False),
                pickup=Location(lat=31.2530, lng=34.7915, address="Be'er Sheva Warehouse"),
                dropoff=Location(lat=31.2600, lng=34.8000, address="Southern Outpost"),
                priority=Priority.high,
                created_at=now,
                updated_at=now,
            ),
        ]

        sample_drivers: List[Driver] = [
            Driver(
                id="drv_001",
                name="Alice Ronen",
                email="alice@hamilog.dev",
                phone="+972-50-111-1111",
                car_type=CarType.sedan,
                status=DriverStatus.available,
                current_location=Location(lat=32.0800, lng=34.7800, address="Central Tel Aviv"),
            ),
            Driver(
                id="drv_002",
                name="Bob Levi",
                email="bob@hamilog.dev",
                phone="+972-50-222-2222",
                car_type=CarType.suv,
                status=DriverStatus.available,
                current_location=Location(lat=31.7700, lng=35.2100, address="Jerusalem Center"),
            ),
            Driver(
                id="drv_003",
                name="Carol Mizrahi",
                email="carol@hamilog.dev",
                phone="+972-50-333-3333",
                car_type=CarType.van,
                status=DriverStatus.available,
                current_location=Location(lat=32.7900, lng=34.9900, address="Haifa Port Area"),
            ),
            Driver(
                id="drv_004",
                name="Dan Shapira",
                email="dan@hamilog.dev",
                phone="+972-50-444-4444",
                car_type=CarType.refrigerated_van,
                status=DriverStatus.available,
                current_location=Location(lat=32.0900, lng=34.7850, address="North Tel Aviv"),
            ),
        ]

        for m in sample_missions:
            self.missions[m.id] = m.model_dump()
        for d in sample_drivers:
            self.drivers[d.id] = d.model_dump()

    # ----- Mission CRUD -----------------------------------------------------

    def get_all_missions(self) -> List[dict]:
        """Return every mission in the store."""
        return list(self.missions.values())

    def get_mission_by_id(self, mission_id: str) -> Optional[dict]:
        """Fetch a single mission by its ID, or ``None``."""
        return self.missions.get(mission_id)

    def create_mission(self, mission_data: dict) -> dict:
        """
        Insert a new mission.  If no ``id`` is provided one will be
        auto-generated.  Timestamps are set to *now*.
        """
        now = datetime.now(timezone.utc)
        mission_data.setdefault("id", f"msn_{uuid.uuid4().hex[:8]}")
        mission_data.setdefault("status", MissionStatus.available.value)
        mission_data.setdefault("created_at", now)
        mission_data["updated_at"] = now
        self.missions[mission_data["id"]] = mission_data
        return mission_data

    def update_mission_status(
        self,
        mission_id: str,
        status: str,
        driver_id: Optional[str] = None,
    ) -> Optional[dict]:
        """
        Transition a mission to a new status.  Optionally attach a driver.
        Returns the updated mission dict, or ``None`` if not found.
        """
        mission = self.missions.get(mission_id)
        if mission is None:
            return None
        mission["status"] = status
        mission["updated_at"] = datetime.now(timezone.utc)
        if driver_id is not None:
            mission["assigned_driver_id"] = driver_id
        return mission

    def get_missions_by_status(self, status: str) -> List[dict]:
        """Return all missions that match the given status string."""
        return [m for m in self.missions.values() if m.get("status") == status]

    def get_missions_by_driver(self, driver_id: str) -> List[dict]:
        """Return missions currently assigned to a specific driver."""
        return [
            m for m in self.missions.values()
            if m.get("assigned_driver_id") == driver_id
        ]

    # ----- Driver CRUD ------------------------------------------------------

    def get_all_drivers(self) -> List[dict]:
        """Return every driver in the store."""
        return list(self.drivers.values())

    def get_driver_by_id(self, driver_id: str) -> Optional[dict]:
        """Fetch a single driver by ID, or ``None``."""
        return self.drivers.get(driver_id)

    def create_driver(self, driver_data: dict) -> dict:
        """Insert a new driver into the store."""
        self.drivers[driver_data["id"]] = driver_data
        return driver_data

    def update_driver_status(
        self,
        driver_id: str,
        status: str,
        mission_id: Optional[str] = None,
    ) -> Optional[dict]:
        """
        Change a driver's availability status and optionally link them to
        a mission.  Returns ``None`` if the driver is not found.
        """
        driver = self.drivers.get(driver_id)
        if driver is None:
            return None
        driver["status"] = status
        if mission_id is not None:
            driver["current_mission_id"] = mission_id
        return driver

    def update_driver_location(
        self,
        driver_id: str,
        location: dict,
    ) -> Optional[dict]:
        """
        Store the latest GPS fix for a driver.  Called by the GPS WebSocket
        handler.
        """
        driver = self.drivers.get(driver_id)
        if driver is None:
            return None
        driver["current_location"] = location
        return driver


# ---------------------------------------------------------------------------
# Constraint Engine
# ---------------------------------------------------------------------------

def check_driver_mission_compatibility(
    driver: dict,
    mission: dict,
) -> Tuple[bool, str]:
    """
    Determine whether *driver* is allowed to accept *mission*.

    Checks (in order):
        1. Driver must have status ``available``.
        2. Cargo weight must not exceed the vehicle's max weight.
        3. Cargo volume must not exceed the vehicle's max volume.
        4. If the cargo requires cooling the vehicle must support it.

    Returns:
        A ``(compatible: bool, reason: str)`` tuple.  When compatible is
        ``True`` the reason is simply ``'Compatible'``.
    """
    # 1. Driver availability
    driver_status = driver.get("status")
    if isinstance(driver_status, DriverStatus):
        driver_status = driver_status.value
    if driver_status != DriverStatus.available.value:
        return False, f"Driver is not available (status: {driver_status})"

    # Resolve car specs
    car_type_raw = driver.get("car_type")
    if isinstance(car_type_raw, str):
        car_type_raw = CarType(car_type_raw)
    specs = CAR_SPECS[car_type_raw]

    # Resolve cargo — could be a dict or a CargoSpecifications instance
    cargo = mission.get("cargo", {})
    if isinstance(cargo, CargoSpecifications):
        cargo = cargo.model_dump()

    weight = cargo.get("weight_kg", 0)
    volume = cargo.get("volume_liters", 0)
    needs_cooling = cargo.get("requires_cooling", False)

    # 2. Weight check
    if weight > specs["max_weight"]:
        return (
            False,
            f"Cargo weight ({weight} kg) exceeds {car_type_raw.value} max ({specs['max_weight']} kg)",
        )

    # 3. Volume check
    if volume > specs["max_volume"]:
        return (
            False,
            f"Cargo volume ({volume} L) exceeds {car_type_raw.value} max ({specs['max_volume']} L)",
        )

    # 4. Cooling check
    if needs_cooling and not specs["cooling"]:
        return False, f"{car_type_raw.value} does not support cooling"

    return True, "Compatible"


def get_compatible_missions(driver: dict, db: InMemoryDB) -> List[dict]:
    """
    Return all *available* missions from ``db`` that the given driver can
    physically transport.
    """
    available = db.get_missions_by_status(MissionStatus.available.value)
    compatible: List[dict] = []
    for mission in available:
        ok, _ = check_driver_mission_compatibility(driver, mission)
        if ok:
            compatible.append(mission)
    return compatible


def calculate_match_score(driver: dict, mission: dict) -> float:
    """
    Produce a 0.0–1.0 score indicating how well a driver's vehicle
    matches the mission cargo.

    Scoring logic:
        * **Capacity utilisation (70 % of score)** — A tighter fit
          (cargo closer to vehicle limits) is *preferred* because it
          means the vehicle isn't wastefully oversized for the load.
        * **Priority bonus (30 % of score)** — Higher-priority missions
          receive a flat bonus so they float to the top of sorted lists.

    If the driver is *incompatible* with the mission the score is ``0.0``.
    """
    ok, _ = check_driver_mission_compatibility(driver, mission)
    if not ok:
        return 0.0

    # --- Capacity utilisation (0.0 – 1.0) --------------------------------
    car_type_raw = driver.get("car_type")
    if isinstance(car_type_raw, str):
        car_type_raw = CarType(car_type_raw)
    specs = CAR_SPECS[car_type_raw]

    cargo = mission.get("cargo", {})
    if isinstance(cargo, CargoSpecifications):
        cargo = cargo.model_dump()

    weight_ratio = cargo.get("weight_kg", 0) / specs["max_weight"] if specs["max_weight"] else 0
    volume_ratio = cargo.get("volume_liters", 0) / specs["max_volume"] if specs["max_volume"] else 0

    # Average of the two ratios — closer to 1.0 means tighter fit
    utilisation = (weight_ratio + volume_ratio) / 2.0

    # --- Priority bonus (0.0 – 1.0) --------------------------------------
    priority_raw = mission.get("priority", Priority.medium.value)
    if isinstance(priority_raw, Priority):
        priority_raw = priority_raw.value
    priority_map = {
        Priority.low.value: 0.1,
        Priority.medium.value: 0.4,
        Priority.high.value: 0.7,
        Priority.critical.value: 1.0,
    }
    priority_score = priority_map.get(priority_raw, 0.4)

    # --- Weighted combination --------------------------------------------
    score = 0.70 * utilisation + 0.30 * priority_score
    return round(min(score, 1.0), 4)
