"""Backend service helpers."""
