"use client";

import { useState } from "react";

interface TextToSpeechButtonProps {
  title?: string;
  pickup?: string;
  destination?: string;
  priority?: string;
  status?: string;
}

export default function TextToSpeechButton({
  title = "Unknown",
  pickup = "Unknown",
  destination = "Unknown",
  priority = "Unknown",
  status = "Unknown",
}: TextToSpeechButtonProps) {
  const [isPlaying, setIsPlaying] = useState(false);

  const handleSpeech = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (isPlaying) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
      return;
    }

    const textToRead = `${title}. Pickup: ${pickup}. Destination: ${destination}. Priority: ${priority}. Status: ${status}.`;
    // Auto-detect language: Check if text contains Hebrew characters
    const isHebrew = /[\u0590-\u05FF]/.test(textToRead);

    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.lang = isHebrew ? "he-IL" : "en-US";
    utterance.onend = () => setIsPlaying(false);
    utterance.onerror = () => setIsPlaying(false);

    setIsPlaying(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <button
      type="button"
      onClick={handleSpeech}
      className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-700/50 text-sm text-white transition-colors hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500"
      title="Read mission details aloud"
      aria-label="Read mission details aloud"
    >
      {isPlaying ? "⏹️" : "🔊"}
    </button>
  );
}